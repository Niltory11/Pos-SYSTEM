<?php
$host = "localhost";
$port = 3307;
$user = "u887634221_roby"; // Replace with your username
$password = "!ubUSW=2sO3"; // Replace with your password if needed
$dbname = "u887634221_roby";

// Create a connection
$conn = new mysqli($host, $user, $password, $dbname, $port);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully!";
?>